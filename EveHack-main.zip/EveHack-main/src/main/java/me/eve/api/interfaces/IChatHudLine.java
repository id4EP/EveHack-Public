package me.eve.api.interfaces;

public interface IChatHudLine {
    int eve_nextgen_master$getId();
    void eve_nextgen_master$setId(int id);
}
