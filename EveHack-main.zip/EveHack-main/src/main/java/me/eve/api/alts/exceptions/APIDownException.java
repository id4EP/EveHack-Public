package me.eve.api.alts.exceptions;

public class APIDownException extends Exception {
	private static final long serialVersionUID = -3514931511912106574L;
}
