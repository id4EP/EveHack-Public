package me.eve.api.interfaces;

public interface IMC {
	
	void setItemUseCooldown(int itemUseCooldown);

	int getItemUseCooldown();

}
