package me.eve.api.util;

import me.eve.Eve;
import me.eve.api.managers.RotationManager;
import me.eve.asm.accessors.IClientWorld;
import me.eve.mod.modules.settings.SwingMode;
import net.minecraft.block.Blocks;
import net.minecraft.client.network.PendingUpdateManager;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import org.jetbrains.annotations.NotNull;

public class EntityUtil implements Wrapper {
    public static boolean rotating = false;
    public static boolean isHoldingWeapon(PlayerEntity player) {
        return player.getMainHandStack().getItem() instanceof SwordItem || player.getMainHandStack().getItem() instanceof AxeItem;
    }
    public static boolean isUsing() {
        return mc.player.isUsingItem();
    }
    public static boolean isInsideBlock() {
        if (BlockUtil.getBlock(EntityUtil.getPlayerPos(true)) == Blocks.ENDER_CHEST) return true;
        return mc.world.canCollide(mc.player, mc.player.getBoundingBox());
    }
    public static int getDamagePercent(ItemStack stack) {
        return (int) ((stack.getMaxDamage() - stack.getDamage()) / Math.max(0.1, stack.getMaxDamage()) * 100.0f);
    }
    public static boolean isArmorLow(PlayerEntity player, int durability) {
        for (ItemStack piece : player.getArmorItems()) {

            if (piece == null || piece.isEmpty()) {
                return true;
            }

            if (getDamagePercent(piece) >= durability) continue;
            return true;
        }
        return false;
    }
    public static float[] getLegitRotations(Vec3d vec) {
        Vec3d eyesPos = getEyesPos();
        double diffX = vec.x - eyesPos.x;
        double diffY = vec.y - eyesPos.y;
        double diffZ = vec.z - eyesPos.z;
        double diffXZ = Math.sqrt(diffX * diffX + diffZ * diffZ);
        float yaw = (float) Math.toDegrees(Math.atan2(diffZ, diffX)) - 90.0f;
        float pitch = (float) (-Math.toDegrees(Math.atan2(diffY, diffXZ)));
        return new float[]{mc.player.getYaw() + MathHelper.wrapDegrees(yaw - mc.player.getYaw()), mc.player.getPitch() + MathHelper.wrapDegrees(pitch - mc.player.getPitch())};
    }
    public static float getHealth(Entity entity) {
        if (entity.isLiving()) {
            LivingEntity livingBase = (LivingEntity) entity;
            return livingBase.getHealth() + livingBase.getAbsorptionAmount();
        }
        return 0.0f;
    }
    public static BlockPos getPlayerPos() {
        return new BlockPos(MathHelper.floor(mc.player.getX()), MathHelper.floor(mc.player.getY()), MathHelper.floor(mc.player.getZ()));
    }

    public static BlockPos getEntityPos(Entity entity) {
        return new BlockPos(MathHelper.floor(entity.getX()), MathHelper.floor(entity.getY()), MathHelper.floor(entity.getZ()));
    }

    public static BlockPos getPlayerPos(boolean fix) {
        return new BlockPos(MathHelper.floor(mc.player.getX()), MathHelper.floor(mc.player.getY() + (fix ? 0.5 : 0)), MathHelper.floor(mc.player.getZ()));
    }

    public static BlockPos getEntityPos(Entity entity, boolean fix) {
        return new BlockPos(MathHelper.floor(entity.getX()), MathHelper.floor(entity.getY() + (fix ? 0.5 : 0)), MathHelper.floor(entity.getZ()));
    }


    public static @NotNull Vec3d getEyesPos() {
        return mc.player.getEyePos();
    }

    public static boolean canSee(BlockPos pos, Direction side) {
        Vec3d testVec = new Vec3d(pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() +0.5).add(side.getVector().getX() * 0.5, side.getVector().getY() * 0.5, side.getVector().getZ() * 0.5);
        HitResult result = mc.world.raycast(new RaycastContext(getEyesPos(), testVec, RaycastContext.ShapeType.OUTLINE, RaycastContext.FluidHandling.NONE, mc.player));
        return result == null || result.getType() == HitResult.Type.MISS;
    }

    public static void sendYawAndPitch(float yaw, float pitch) {
        sendLook(new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, mc.player.isOnGround()));
    }

    public static void faceVector(Vec3d directionVec) {
        RotationManager.TIMER.reset();
        RotationManager.directionVec = directionVec;
        float[] angle = getLegitRotations(directionVec);
        if (angle[0] == Eve.ROTATION.lastYaw && angle[1] == Eve.ROTATION.lastPitch) return;
        sendLook(new PlayerMoveC2SPacket.LookAndOnGround(angle[0], angle[1], mc.player.isOnGround()));
    }

    public static void sendLook(PlayerMoveC2SPacket.LookAndOnGround lookAndOnGround) {
        if (lookAndOnGround.getYaw(114514) == Eve.ROTATION.lastYaw && lookAndOnGround.getPitch(114514) == Eve.ROTATION.lastPitch) {
            return;
        }
        rotating = true;
        mc.player.networkHandler.sendPacket(lookAndOnGround);
        rotating = false;
    }


    public static void facePosSide(BlockPos pos, Direction side) {
        final Vec3d hitVec = pos.toCenterPos().add(new Vec3d(side.getVector().getX() * 0.5, side.getVector().getY() * 0.5, side.getVector().getZ() * 0.5));
        faceVector(hitVec);
    }

    public static int getWorldActionId(ClientWorld world) {
        PendingUpdateManager pum = getUpdateManager(world);
        int p = pum.getSequence();
        pum.close();
        return p;
    }
    public static boolean isElytraFlying() {
        return mc.player.isFallFlying();
    }

    static PendingUpdateManager getUpdateManager(ClientWorld world) {
        return ((IClientWorld) world).acquirePendingUpdateManager();
    }

    public static void swingHand(Hand hand, SwingMode mode) {
        switch (mode) {
            case Normal -> mc.player.swingHand(hand);
            case Client -> mc.player.swingHand(hand, false);
            case Server -> mc.player.networkHandler.sendPacket(new HandSwingC2SPacket(hand));
        }
    }

    public static void sync() {
        if (Eve.HUD.inventorySync.getValue()) mc.player.networkHandler.sendPacket(new CloseHandledScreenC2SPacket(mc.player.currentScreenHandler.syncId));
    }
}
