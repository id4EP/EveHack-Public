package me.eve.api.events.impl;

import me.eve.api.events.Event;

public class UpdateWalkingEvent extends Event {
    public UpdateWalkingEvent(Stage stage) {
        super(stage);
    }
}
