package me.eve.api.interfaces;

import net.minecraft.text.Text;

public interface IChatHud {
    void eve_nextgen_master$add(Text message, int id);
}
