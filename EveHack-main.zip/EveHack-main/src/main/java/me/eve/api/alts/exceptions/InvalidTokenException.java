package me.eve.api.alts.exceptions;

public class InvalidTokenException extends Exception {
	private static final long serialVersionUID = -264097897271382356L;
}
