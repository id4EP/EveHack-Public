package me.eve.asm.mixins;

import me.eve.Eve;
import me.eve.api.managers.ShaderManager;
import me.eve.mod.modules.impl.render.ShaderChams;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import static me.eve.api.util.Wrapper.mc;
@Mixin(WorldRenderer.class)
public abstract class MixinWorldRenderer {
	@Shadow
	protected abstract void renderEndSky(MatrixStack matrices);

	@Inject(at = { @At("RETURN") }, method = { "render" })
	private void onRenderWorld(MatrixStack matrixStack, float tickDelta, long limitTime, boolean renderBlockOutline,
			Camera camera, GameRenderer gameRenderer, LightmapTextureManager lightmapTextureManager, Matrix4f matrix4f,
			CallbackInfo info) {
		Eve.MODULE.render3D(matrixStack);
	}

	@Redirect(method = "render", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gl/PostEffectProcessor;render(F)V", ordinal = 0))
	void replaceShaderHook(PostEffectProcessor instance, float tickDelta) {
		ShaderManager.Shader shaders = (ShaderManager.Shader) ShaderChams.INSTANCE.mode.getValue();
		if (ShaderChams.INSTANCE.isOn() && mc.world != null) {
			Eve.SHADER.setupShader(shaders, Eve.SHADER.getShaderOutline(shaders));
		} else {
			instance.render(tickDelta);
		}
	}

	@Inject(method = "renderSky(Lnet/minecraft/client/util/math/MatrixStack;Lorg/joml/Matrix4f;FLnet/minecraft/client/render/Camera;ZLjava/lang/Runnable;)V", at = @At(value = "HEAD"), cancellable = true)
	private void renderSkyHead(MatrixStack matrices, Matrix4f matrix4f, float tickDelta, Camera camera, boolean bl, Runnable runnable, CallbackInfo info) {
		if (ShaderChams.INSTANCE.isOn() && ShaderChams.INSTANCE.sky.getValue()) {
			Eve.SHADER.applyShader(() -> renderEndSky(matrices), (ShaderManager.Shader) ShaderChams.INSTANCE.skyMode.getValue());
			info.cancel();
		}
	}
}
