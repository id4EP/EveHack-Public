package me.eve;

import me.eve.api.events.eventbus.EventBus;
import me.eve.api.managers.*;
import net.fabricmc.api.ModInitializer;
import net.minecraft.client.gui.DrawContext;

import java.lang.invoke.MethodHandles;

public final class Eve implements ModInitializer {

	@Override
	public void onInitialize()
	{
		load();
	}

	public static final String LOG_NAME = "EveHack";
	public static final String VERSION = "1.0";
	public static final String title = "DreamDev欢迎你使用Eve客户端";
	public static String PREFIX = "+";
	public static final EventBus EVENT_BUS = new EventBus();
	// Systems
	public static ModuleManager MODULE;
	public static CommandManager COMMAND;
	public static AltManager ALT;
	public static HudManager HUD;
	public static ConfigManager CONFIG;
	public static RotationManager ROTATION;
	public static BreakManager BREAK;
	public static PopManager POP;
	public static FriendManager FRIEND;
	public static TimerManager TIMER;
	public static ShaderManager SHADER;
	public static boolean loaded = false;


	public static void update() {
		if (!loaded) return;
		MODULE.onUpdate();
		HUD.update();
		POP.update();
	}

	public static void drawHUD(DrawContext context, float partialTicks) {
		if (!loaded) return;
		if (!HUD.isClickGuiOpen()) HUD.draw(context, partialTicks);
	}

	public static void load() {
		System.out.println("[" + Eve.LOG_NAME + "] Starting Client");
		EVENT_BUS.registerLambdaFactory("me", (lookupInMethod, klass) -> (MethodHandles.Lookup) lookupInMethod.invoke(null, klass, MethodHandles.lookup()));
		CONFIG = new ConfigManager();
		PREFIX = Eve.CONFIG.getSettingString("prefix", PREFIX);
		MODULE = new ModuleManager();
		COMMAND = new CommandManager();
		HUD = new HudManager();
		ALT = new AltManager();
		FRIEND = new FriendManager();
		ROTATION = new RotationManager();
		BREAK = new BreakManager();
		POP = new PopManager();
		TIMER = new TimerManager();
		SHADER = new ShaderManager();
		CONFIG.loadSettings();
		System.out.println("[" + Eve.LOG_NAME + "] Initialized and ready to play!");

		Runtime.getRuntime().addShutdownHook(new Thread(Eve::save));
		loaded = true;
	}

	public static void unload() {
		loaded = false;
		System.out.println("[" + Eve.LOG_NAME + "] Unloading..");
		EVENT_BUS.listenerMap.clear();
		CONFIG = null;
		MODULE = null;
		COMMAND = null;
		HUD = null;
		ALT = null;
		FRIEND = null;
		ROTATION = null;
		POP = null;
		TIMER = null;
		System.out.println("[" + Eve.LOG_NAME + "] Unloading success!");
	}
	public static void save() {
		System.out.println("[" + Eve.LOG_NAME + "] Saving...");
		CONFIG.saveSettings();
		FRIEND.saveFriends();
		ALT.saveAlts();
		System.out.println("[" + Eve.LOG_NAME + "] Saving success!");
	}

	public static String getName() {
		switch ((HudManager.HackName) HUD.hackName.getValue()) {
			case EveHack -> {
				return "\uD835\uDEF4\uD835\uDF08\uD835\uDF00";
			}
			case MoonGod -> {
				return "MoonGod";
			}
			case MoonBlade -> {
				return "ＭｏｏｎＢｌａｄｅ";
			}
			case StarEmoji -> {
				return "☽";
			}
			case Shuhao1337 -> {
				return "🌸shuhao1337🌸";
			}
			case DreamDev -> {
				return "ᕲreamᕲev";
			}
		}
		return "\uD835\uDEF4\uD835\uDF08\uD835\uDF00";
	}
}
