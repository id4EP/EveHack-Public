package me.eve.mod.commands.impl;

import me.eve.Eve;
import me.eve.api.managers.CommandManager;
import me.eve.mod.commands.Command;

import java.util.List;

public class ReloadCommand extends Command {

	public ReloadCommand() {
		super("reload", "debug", "");
	}

	@Override
	public void runCommand(String[] parameters) {
		CommandManager.sendChatMessage("\u00a7e[!] \u00a7fReloading..");
		Eve.unload();
		Eve.load();
	}

	@Override
	public String[] getAutocorrect(int count, List<String> seperated) {
		return null;
	}
}
