/**
 * Anti-Invis Module
 */
package me.eve.mod.modules.impl.player;

import me.eve.Eve;
import me.eve.api.events.eventbus.EventHandler;
import me.eve.api.events.impl.PacketEvent;
import me.eve.asm.accessors.IPlayerPositionLookS2CPacket;
import me.eve.mod.modules.Module;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;

public class NoRotate extends Module {
	public static NoRotate INSTANCE;
	public NoRotate() {
		super("NoRotate", Category.Player);
		INSTANCE = this;
	}

	@EventHandler
	public void onPacketReceive(PacketEvent.Receive event){
		if(nullCheck()) return;
		if(event.getPacket() instanceof PlayerPositionLookS2CPacket packet){
			float yaw = mc.player.getYaw();
			float pitch = mc.player.getPitch();
			if (Eve.ROTATION.rotating) {
				yaw = Eve.ROTATION.preYaw;
				pitch = Eve.ROTATION.prePitch;
			}
			((IPlayerPositionLookS2CPacket) packet).setYaw(yaw);
			((IPlayerPositionLookS2CPacket) packet).setPitch(pitch);
		}
	}
}