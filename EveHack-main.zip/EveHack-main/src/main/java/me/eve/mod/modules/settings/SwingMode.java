package me.eve.mod.modules.settings;

public enum SwingMode {
    Normal,
    Client,
    Server,
    None
}
