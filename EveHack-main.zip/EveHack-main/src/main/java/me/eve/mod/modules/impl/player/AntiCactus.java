/**
 * AntiCactus Module
 */
package me.eve.mod.modules.impl.player;

import me.eve.mod.modules.Module;

public class AntiCactus extends Module {
	public static AntiCactus INSTANCE;
	public AntiCactus() {
		super("AntiCactus", Category.Player);
		this.setDescription("Prevents blocks from hurting you.");
		INSTANCE = this;
	}
}