package me.eve.mod.modules.impl.misc;

import me.eve.mod.modules.Module;

public class SilentDisconnect extends Module {
    public static SilentDisconnect INSTANCE = new SilentDisconnect();

    public SilentDisconnect() {
        super("SilentDisconnect", Category.Misc);
        INSTANCE = this;
    }
}
