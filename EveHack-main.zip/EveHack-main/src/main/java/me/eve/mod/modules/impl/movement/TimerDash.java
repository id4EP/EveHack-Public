package me.eve.mod.modules.impl.movement;

import me.eve.Eve;
import me.eve.api.events.eventbus.EventHandler;
import me.eve.api.events.impl.RotateEvent;
import me.eve.api.util.EntityUtil;
import me.eve.api.util.FadeUtils;
import me.eve.api.util.MovementUtil;
import me.eve.api.util.Timer;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.BooleanSetting;
import me.eve.mod.modules.settings.impl.SliderSetting;
import net.minecraft.client.gui.DrawContext;

import java.text.DecimalFormat;

public class TimerDash extends Module {
	private final SliderSetting multiplier = add(new SliderSetting("Speed", 2f, 1f, 10f, 0.1f));
	private final SliderSetting accumulate = add(new SliderSetting("Accumulate", 2000f, 1f, 10000f, 50f));
	private final BooleanSetting smooth = add(new BooleanSetting("Smooth", true));
	private final BooleanSetting indicator = add(new BooleanSetting("Indicator", true));
	public static TimerDash INSTANCE;
	public TimerDash() {
		super("TimerDash", Category.Movement);
		INSTANCE = this;
	}

	private final Timer timer = new Timer();
	private final Timer timer2 = new Timer();
	
	private final FadeUtils end = new FadeUtils(500);

	long lastMs = 0;
	boolean moving = false;
	@Override
	public void onRender2D(DrawContext drawContext, float tickDelta) {
		timer.setMs(Math.min(Math.max(0, timer.getPassedTimeMs()), accumulate.getValueInt()));
		if ((MovementUtil.isMoving() || HoleSnap.INSTANCE.isOn()) && !EntityUtil.isInsideBlock()) {
			if (!moving) {
				timer2.reset();
				lastMs = timer.getPassedTimeMs();
				moving = true;
			}

			timer.reset();

			if (timer2.passed(lastMs)) {
				if (HoleSnap.INSTANCE.isOn()) {
					Eve.TIMER.set(HoleSnap.INSTANCE.multiplier.getValueFloat());
				} else if (!TickShift.INSTANCE.isOn()) Eve.TIMER.reset();
			} else {
				if (smooth.getValue()) {
					double timer = 1 + (1 - end.easeOutQuad()) * (multiplier.getValueFloat() - 1) * (lastMs / accumulate.getValue());
					Eve.TIMER.set((float) Math.max(1, timer));
				} else {
					Eve.TIMER.set(multiplier.getValueFloat());
				}
			}
		} else {
			if (moving) {
				Eve.TIMER.reset();
				timer.setMs(Math.max(lastMs - timer2.getPassedTimeMs(), 0));
				moving = false;
			}
			end.setLength(timer.getPassedTimeMs());
			end.reset();
		}

		if (indicator.getValue()) {
			double current = (moving ? (Math.max(lastMs - timer2.getPassedTimeMs(), 0)) : timer.getPassedTimeMs());
			double max = accumulate.getValue();
			DecimalFormat df = new DecimalFormat("0.0");
			String text = df.format(current / max * 100L) + "%";
			drawContext.drawText(mc.textRenderer, text, mc.getWindow().getScaledWidth() / 2 - mc.textRenderer.getWidth(text) / 2, mc.getWindow().getScaledHeight() / 2 + mc.textRenderer.fontHeight, -1, true);
		}
	}

	public void onDisable() {
		Eve.TIMER.reset();
	}

	public void onEnable() {
		Eve.TIMER.reset();
	}

	public static float nextFloat(final float startInclusive, final float endInclusive) {
		return (startInclusive == endInclusive || endInclusive - startInclusive <= 0.0f) ? startInclusive : ((float) (startInclusive + (endInclusive - startInclusive) * Math.random()));
	}

	@EventHandler
	public final void RotateEvent(RotateEvent event) {
		event.setRotation(event.getYaw() + nextFloat(1.0f, 3.0f), event.getPitch() + nextFloat(1.0f, 3.0f));
	}
}