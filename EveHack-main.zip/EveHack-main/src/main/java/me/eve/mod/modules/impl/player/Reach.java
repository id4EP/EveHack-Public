package me.eve.mod.modules.impl.player;

import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.SliderSetting;

public class Reach extends Module {
	public static Reach INSTANCE;
	public final SliderSetting distance = add(new SliderSetting("Distance", 5f, 1f, 15f, 1f));

	public Reach() {
		super("Reach", Category.Player);
		INSTANCE = this;
	}
}