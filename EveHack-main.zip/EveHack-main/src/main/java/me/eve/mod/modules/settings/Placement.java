package me.eve.mod.modules.settings;

public enum Placement {
    Vanilla,
    Strict,
    Legit,
    AirPlace
}
