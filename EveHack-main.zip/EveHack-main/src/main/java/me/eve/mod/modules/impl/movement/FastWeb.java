package me.eve.mod.modules.impl.movement;

import me.eve.Eve;
import me.eve.api.util.MovementUtil;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.impl.combat.AutoPush;
import me.eve.mod.modules.settings.impl.BooleanSetting;
import me.eve.mod.modules.settings.impl.EnumSetting;
import me.eve.mod.modules.settings.impl.SliderSetting;


public class FastWeb extends Module {
    public static FastWeb INSTANCE;
    public final EnumSetting mode =
            add(new EnumSetting("Mode", Mode.Vanilla));
    private final SliderSetting fastSpeed =
            add(new SliderSetting("Speed", 3.0, 0.0, 8.0, v -> mode.getValue() == Mode.Vanilla || mode.getValue() == Mode.Strict));
    public final BooleanSetting onlySneak = add(new BooleanSetting("OnlySneak", true));

    public FastWeb() {
        super("FastWeb", "So you don't need to keep timer on keybind", Category.Movement);
        INSTANCE = this;
    }

    @Override
    public String getInfo() {
        return mode.getValue().name();
    }

    @Override
    public void onUpdate() {
        if (nullCheck()) return;
        Eve.TIMER.set(fastSpeed.getValueFloat());
        boolean work = (!mc.player.isOnGround()) && (mc.options.sneakKey.isPressed() || !onlySneak.getValue()) && AutoPush.isInWeb(mc.player);
        if (work && mode.getValue() == Mode.Vanilla) {
                MovementUtil.setMotionY(MovementUtil.getMotionY() - fastSpeed.getValue());
        }
    }
    public enum Mode {
        Vanilla,
        Strict,
    }
}
