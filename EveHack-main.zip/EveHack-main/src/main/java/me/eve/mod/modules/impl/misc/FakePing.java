package me.eve.mod.modules.impl.misc;

import me.eve.api.events.eventbus.EventHandler;
import me.eve.api.events.impl.PacketEvent;
import me.eve.api.events.impl.UpdateWalkingEvent;
import me.eve.api.util.MathUtil;
import me.eve.api.util.Timer;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.SliderSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.s2c.play.KeepAliveS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayPingS2CPacket;

import java.util.ArrayList;
import java.util.List;

public class FakePing extends Module {
    public FakePing() {
        super("FakePing", Category.Misc);
    }
    private final SliderSetting minPing = add(new SliderSetting("MinDelay", 50, 0, 5000, 1));
    private final SliderSetting maxPing = add(new SliderSetting("MaxDelay", 100, 0, 5000, 1));
    private final List<Packet> packet = new ArrayList<>();

    @EventHandler
    public void onPacket(PacketEvent.Receive event) {
        if (nullCheck() || mc.player.isDead() || event.isCancel()) return;
        if (event.getPacket() instanceof PlayPingS2CPacket p) {
            event.cancel();
            packet.add(new Packet(p));
        } else if (event.getPacket() instanceof KeepAliveS2CPacket p) {
            event.cancel();
            packet.add(new Packet(p));
        }
    }

    @Override
    public void onUpdate() {
        update();
    }

    @EventHandler
    public void onUpdateWalking(UpdateWalkingEvent event) {
        update();
    }

    @Override
    public void onRender3D(MatrixStack matrixStack, float partialTicks) {
        update();
    }

    private void update() {
        if (nullCheck()) {
            packet.clear();
            return;
        }
        packet.removeIf(Packet::send);
    }

    private class Packet {
        KeepAliveS2CPacket kp = null;
        PlayPingS2CPacket pp = null;
        final Timer timer;
        final int ping;
        public Packet(PlayPingS2CPacket p) {
            pp = p;
            timer = new Timer();
            timer.reset();
            ping = (int) MathUtil.random(minPing.getValue(), maxPing.getValue());
        }

        public Packet(KeepAliveS2CPacket p) {
            kp = p;
            timer = new Timer();
            timer.reset();
            ping = (int) MathUtil.random(minPing.getValue(), maxPing.getValue());
        }

        public boolean send() {
            if (timer.passedMs(ping)) {
                if (kp != null) {
                    kp.apply(mc.player.networkHandler);
                }
                if (pp != null) {
                    pp.apply(mc.player.networkHandler);
                }
                return true;
            } else {
                return false;
            }
        }
    }
}
