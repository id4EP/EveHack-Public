/**
 * AntiCactus Module
 */
package me.eve.mod.modules.impl.misc;

import me.eve.mod.modules.Module;

public class ShulkerViewer extends Module {
	public static ShulkerViewer INSTANCE;
	public ShulkerViewer() {
		super("ShulkerViewer", Category.Misc);
		INSTANCE = this;
	}
}