/**
 * NoSlowdown Module
 */
package me.eve.mod.modules.impl.movement;

import me.eve.mod.modules.Module;

public class NoSlowdown extends Module {
	public static NoSlowdown INSTANCE;
	public NoSlowdown() {
		super("NoSlowdown", Category.Movement);
		this.setDescription("Prevents the player from being slowed down by blocks.");
		INSTANCE = this;
	}
}
