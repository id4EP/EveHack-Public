package me.eve.mod.modules.impl.combat;

import me.eve.api.util.*;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.BooleanSetting;
import me.eve.mod.modules.settings.impl.SliderSetting;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.block.FacingBlock;
import net.minecraft.block.PistonBlock;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;

import static me.eve.api.util.BlockUtil.getBlock;
import static me.eve.api.util.BlockUtil.getState;
public class PullCrystal extends Module {
    private final SliderSetting range =
            add(new SliderSetting("Range", 5.0f, 1.0f, 8.0f));
    private final BooleanSetting rotate =
            add(new BooleanSetting("Rotate", true));
    private final BooleanSetting fire =
            add(new BooleanSetting("Fire", true));
    public final BooleanSetting checkMine = add(new BooleanSetting("CheckMine", true));
    private final BooleanSetting noEating = add(new BooleanSetting("NoEating", true));
    private final BooleanSetting multiPlace =
            add(new BooleanSetting("MultiPlace", false));
    private final BooleanSetting onlyGround =
            add(new BooleanSetting("NoAir", true));
    private final BooleanSetting onlyStatic =
            add(new BooleanSetting("NoMoving", true));
    private final BooleanSetting inventory =
            add(new BooleanSetting("InventorySwap", true));
    private final SliderSetting updateDelay =
            add(new SliderSetting("UpdateDelay", 100, 0, 500));
    private final SliderSetting pistonDelay =
            add(new SliderSetting("PistonDelay", 200, 0, 500));
    private PlayerEntity target = null;
    public static PullCrystal INSTANCE;

    public PullCrystal() {
        super("PullCrystal", "use piston pull crystal and boom", Category.Combat);
        INSTANCE = this;
    }

    private final Timer timer = new Timer();
    private void doSwap(int slot) {
        if (inventory.getValue()) {
            mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, mc.player.getInventory().selectedSlot, SlotActionType.SWAP, mc.player);
        } else {
            InventoryUtil.doSwap(slot);
        }
    }
    public int findItem(Item itemIn) {
        if (inventory.getValue()) {
            return InventoryUtil.findItemInventorySlot(itemIn);
        } else {
            return InventoryUtil.findItem(itemIn);
        }
    }
    public int findBlock(Block blockIn) {
        if (inventory.getValue()) {
            return InventoryUtil.findBlockInventorySlot(blockIn);
        } else {
            return InventoryUtil.findBlock(blockIn);
        }
    }
    public int findClass(Class clazz) {
        if (inventory.getValue()) {
            return InventoryUtil.findClassInventorySlot(clazz);
        } else {
            return InventoryUtil.findClass(clazz);
        }
    }

    @Override
    public void onUpdate() {
        if (!timer.passedMs((long) updateDelay.getValue())) return;
        if (noEating.getValue() && EntityUtil.isUsing()) {
            target = null;
            return;
        }
        if (check(onlyStatic.getValue(), !mc.player.isOnGround(), onlyGround.getValue())) {
            target = null;
            return;
        }
        target = CombatUtil.getClosestEnemy(range.getValue());
        if (target == null) return;
        BlockPos pos = EntityUtil.getEntityPos(target);
        if (breakCrystal(pos.up(0))) {
            timer.reset();
            return;
        }
        if (breakCrystal(pos.up(1))) {
            timer.reset();
            return;
        }
        if (breakCrystal(pos.up(2))) {
            timer.reset();
            return;
        }
        if (breakCrystal(pos.up(3))) {
            timer.reset();
            return;
        }
        if (doPullCrystal(pos)) {
            timer.reset();
            return;
        }
        if (doPullCrystal(new BlockPosX(target.getX() + 0.1, target.getY() + 0.5, target.getZ() + 0.1))) {
            timer.reset();
            return;
        }
        if (doPullCrystal(new BlockPosX(target.getX() - 0.1, target.getY() + 0.5, target.getZ() + 0.1))) {
            timer.reset();
            return;
        }
        if (doPullCrystal(new BlockPosX(target.getX() + 0.1, target.getY() + 0.5, target.getZ() - 0.1)))  {
            timer.reset();
            return;
        }
        if (doPullCrystal(new BlockPosX(target.getX() - 0.1, target.getY() + 0.5, target.getZ() - 0.1)))  {
            timer.reset();
            return;
        }
    }

    private boolean doPullCrystal(BlockPos pos) {
        if (pull(pos.up(2))) return true;
        if (pull(pos.up())) return true;
        if (power(pos.up(2))) return true;
        if (power(pos.up())) return true;
        if (timer.passedMs(pistonDelay.getValueInt())) {
            if (piston(pos.up(2))) return true;
            return piston(pos.up());
        }
        return false;
    }

    public boolean check(boolean onlyStatic, boolean onGround, boolean onlyGround) {
        if (MovementUtil.isMoving() && onlyStatic) return true;
        if (onGround && onlyGround) return true;
        if (findBlock(Blocks.REDSTONE_BLOCK) == -1) return true;
        if (findClass(PistonBlock.class) == -1) return true;
        return findItem(Items.END_CRYSTAL) == -1;
    }

    private static boolean canFire(BlockPos pos) {
        if (BlockUtil.canReplace(pos.down()) || !BlockUtil.canClick(pos.down())) return false;
        return mc.world.isAir(pos);
    }


    private void doFire(BlockPos pos, Direction facing) {
        if (!fire.getValue()) return;
        int fire = findItem(Items.FLINT_AND_STEEL);
        if (fire == -1) return;
        int old = mc.player.getInventory().selectedSlot;

        int[] xOffset = {0, facing.getOffsetZ(), -facing.getOffsetZ()};
        int[] yOffset = {0, 1};
        int[] zOffset = {0, facing.getOffsetX(), -facing.getOffsetX()};
        for (int x : xOffset) {
            for (int y : yOffset) {
                for (int z : zOffset) {
                    if (getBlock(pos.add(x, y, z)) == Blocks.FIRE) {
                        return;
                    }
                }
            }
        }
        for (int x : xOffset) {
            for (int y : yOffset) {
                for (int z : zOffset) {
                    if (canFire(pos.add(x, y, z))) {
                        doSwap(findItem(Items.FLINT_AND_STEEL));
                        placeFire(pos.add(x, y, z));
                        if (inventory.getValue()) {
                            doSwap(fire);
                            EntityUtil.sync();
                        } else {
                            doSwap(old);
                        }
                        return;
                    }
                }
            }
        }
    }

    private void placeFire(BlockPos pos) {
        BlockPos neighbour = pos.offset(Direction.DOWN);
        BlockUtil.clickBlock(neighbour, Direction.UP, this.rotate.getValue());
    }

    @Override
    public String getInfo() {
        if (target != null) return target.getName().getString();
        return null;
    }


    private boolean pistonActive(BlockPos pos, Direction facing, BlockPos oPos) {
        if (pistonActive(pos, facing, oPos, false)) return true;
        return pistonActive(pos, facing, oPos, true);
    }

    public static BlockPos crystalPos;
    private boolean pistonActive(BlockPos pos, Direction facing, BlockPos oPos, boolean up) {
        if (up) pos = pos.up();
        if (!BlockUtil.canPlaceCrystal(oPos.offset(facing, -1)) && !BlockUtil.hasCrystal(oPos.offset(facing, -1)))
            return false;
        if (!(getBlock(pos) instanceof PistonBlock)) return false;
        if (getState(pos).get(FacingBlock.FACING).getOpposite() != facing) return false;
        if (getBlock(pos.offset(facing, -1)) == Blocks.MOVING_PISTON) {
            return true;
        }
        if (getBlock(pos.offset(facing, -1)) != Blocks.PISTON_HEAD) {
            return false;
        }
        for (Direction i : Direction.values()) {
            if (getBlock(pos.offset(i)) == Blocks.REDSTONE_BLOCK) {
                if (!BlockUtil.hasCrystal(oPos.offset(facing, -1))) {
                    int old = mc.player.getInventory().selectedSlot;
                    crystalPos = oPos.offset(facing, -1);
                    int crystal = findItem(Items.END_CRYSTAL);
                    doSwap(crystal);
                    BlockUtil.placeCrystal(oPos.offset(facing, -1), rotate.getValue());
                    if (inventory.getValue()) {
                        doSwap(crystal);
                        EntityUtil.sync();
                    } else {
                        doSwap(old);
                    }
                }
                doFire(oPos, facing);
                powerPos = pos.offset(i);
                PacketMine.INSTANCE.mine(pos.offset(i));
                return true;
            }
        }
        return false;
    }

    private boolean power(BlockPos pos) {
        for (Direction i : Direction.values()) {
            if (i == Direction.DOWN || i == Direction.UP) continue;
            int offsetX = pos.offset(i).getX() - pos.getX();
            int offsetZ = pos.offset(i).getZ() - pos.getZ();
            if (placePower(pos.offset(i, -2), i, pos)) {
                return true;
            }
            if (placePower(pos.offset(i, -2).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
            if (placePower(pos.offset(i, -2).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }

            if (placePower(pos.offset(i, 1).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }
            if (placePower(pos.offset(i, 1).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
            if (placePower(pos.offset(i, -1).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }
            if (placePower(pos.offset(i, -1).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
        }
        return false;
    }

    private boolean piston(BlockPos pos) {
        for (Direction i : Direction.values()) {
            if (i == Direction.DOWN || i == Direction.UP) continue;
            int offsetX = pos.offset(i).getX() - pos.getX();
            int offsetZ = pos.offset(i).getZ() - pos.getZ();
            if (placePiston(pos.offset(i, -2), i, pos)) {
                return true;
            }
            if (placePiston(pos.offset(i, -2).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
            if (placePiston(pos.offset(i, -2).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }

            if (placePiston(pos.offset(i, 1).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }
            if (placePiston(pos.offset(i, 1).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
            if (placePiston(pos.offset(i, -1).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }
            if (placePiston(pos.offset(i, -1).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
        }
        return false;
    }

    private boolean breakCrystal(BlockPos pos) {
        for (EndCrystalEntity entity : mc.world.getNonSpectatingEntities(EndCrystalEntity.class, new Box(pos))) {
            float damage = DamageUtil.calculateDamage(entity.getPos(), target, target, 6);
            if (damage > 6) {
                CombatUtil.attackCrystal(entity, rotate.getValue(), true);
                return true;
            }
        }
        return false;
    }

    private boolean placePower(BlockPos pos, Direction facing, BlockPos oPos) {
        if (placePower(pos, facing, oPos, false)) return true;
        return placePower(pos, facing, oPos, true);
    }

    private boolean placePower(BlockPos pos, Direction facing, BlockPos oPos, boolean up) {
        if (up) pos = pos.up();
        if (!BlockUtil.canPlaceCrystal(oPos.offset(facing, -1)) && !BlockUtil.hasCrystal(oPos.offset(facing, -1)))
            return false;
        if (!(getBlock(pos) instanceof PistonBlock)) return false;
        if (getState(pos).get(FacingBlock.FACING).getOpposite() != facing) return false;
        if (getBlock(pos.offset(facing, -1)) == Blocks.PISTON_HEAD || getBlock(pos.offset(facing, -1)) == Blocks.MOVING_PISTON) {
            return true;
        }
        if (!mc.world.isAir(pos.offset(facing, -1)) && getBlock(pos.offset(facing, -1)) != Blocks.PISTON_HEAD && getBlock(pos.offset(facing, -1)) != Blocks.MOVING_PISTON && getBlock(pos.offset(facing, -1)) != Blocks.FIRE) {
            return false;
        }
        int old = mc.player.getInventory().selectedSlot;
        return placeRedStone(pos, facing, old, oPos);
    }

    private boolean placePiston(BlockPos pos, Direction facing, BlockPos oPos) {
        if (placePiston(pos, facing, oPos, false)) return true;
        return placePiston(pos, facing, oPos, true);
    }

    private boolean placePiston(BlockPos pos, Direction facing, BlockPos oPos, boolean up) {
        if (up) pos = pos.up();
        if (!BlockUtil.canPlaceCrystal(oPos.offset(facing, -1)) && !BlockUtil.hasCrystal(oPos.offset(facing, -1)))
            return false;
        if (!canPlace(pos) && !(getBlock(pos) instanceof PistonBlock)) return false;
        if (getBlock(pos) instanceof PistonBlock && getState(pos).get(FacingBlock.FACING).getOpposite() != facing) return false;
        if (getBlock(pos.offset(facing, -1)) == Blocks.PISTON_HEAD || getBlock(pos.offset(facing, -1)) == Blocks.MOVING_PISTON) {
            return true;
        }
        if (!mc.world.isAir(pos.offset(facing, -1)) && getBlock(pos.offset(facing, -1)) != Blocks.PISTON_HEAD && getBlock(pos.offset(facing, -1)) != Blocks.MOVING_PISTON) {
            return false;
        }
        if ((mc.player.getY() - pos.down().getY() <= -1.0 || mc.player.getY() - pos.down().getY() >= 2.0) && BlockUtil.distanceToXZ(pos.getX() + 0.5, pos.getZ() + 0.5) < 2.6) {
            return false;
        }
        int old = mc.player.getInventory().selectedSlot;
        if (canPlace(pos)) {
            Direction side = BlockUtil.getPlaceSide(pos);
            EntityUtil.facePosSide(pos, side);
            pistonFacing(facing);
            int piston = findClass(PistonBlock.class);
            doSwap(piston);
            BlockUtil.placeBlock(pos, false);
            if (inventory.getValue()) {
                doSwap(piston);
                EntityUtil.sync();
            } else {
                doSwap(old);
            }
            EntityUtil.facePosSide(pos, side);
            if (multiPlace.getValue() && placeRedStone(pos, facing, old, oPos)) return true;
            return true;
        } else {
            return placeRedStone(pos, facing, old, oPos);
        }
    }

    public static void pistonFacing(Direction i) {
        if (i == Direction.EAST) {
            EntityUtil.sendYawAndPitch(-90.0f, 5.0f);
        } else if (i == Direction.WEST) {
            EntityUtil.sendYawAndPitch(90.0f, 5.0f);
        } else if (i == Direction.NORTH) {
            EntityUtil.sendYawAndPitch(180.0f, 5.0f);
        } else if (i == Direction.SOUTH) {
            EntityUtil.sendYawAndPitch(0.0f, 5.0f);
        }
    }
    private boolean placeRedStone(BlockPos pos, Direction facing, int old, BlockPos oPos) {
        for (Direction i : Direction.values()) {
            if (getBlock(pos.offset(i)) == Blocks.REDSTONE_BLOCK) {
                powerPos = pos.offset(i);
                return true;
            }
        }
        Direction bestNeighboring = BlockUtil.getBestNeighboring(pos, facing);
        int power = findBlock(Blocks.REDSTONE_BLOCK);
        if (bestNeighboring != null && !pos.offset(bestNeighboring).equals(oPos.offset(facing, -1)) && !pos.offset(bestNeighboring).equals(oPos.offset(facing, -1).up())) {
            powerPos = pos.offset(bestNeighboring);
            if (BlockUtil.canPlace(powerPos)) {
                doSwap(power);
                BlockUtil.placeBlock(pos.offset(bestNeighboring), rotate.getValue());
                if (inventory.getValue()) {
                    doSwap(power);
                    EntityUtil.sync();
                } else {
                    doSwap(old);
                }
                return true;
            }
        }
        for (Direction i : Direction.values()) {
            if (pos.offset(i).equals(pos.offset(facing, -1))) continue;
            if (pos.offset(i).equals(oPos.offset(facing, -1))) continue;
            if (pos.offset(i).equals(oPos.offset(facing, -1).up())) continue;
            if (BlockUtil.canPlace(pos.offset(i))) {
                powerPos = pos.offset(i);
                doSwap(power);
                BlockUtil.placeBlock(pos.offset(i), true);
                if (inventory.getValue()) {
                    doSwap(power);
                    EntityUtil.sync();
                } else {
                    doSwap(old);
                }
                return true;
            }
        }
        return false;
    }

    private boolean canPlace(BlockPos pos) {
        if (checkMine.getValue() && BlockUtil.isMining(pos)) {
            return false;
        }
        return BlockUtil.canPlace(pos, range.getValueFloat());
    }
    private boolean pull(BlockPos pos) {
        for (Direction i : Direction.values()) {
            if (i == Direction.DOWN || i == Direction.UP) continue;
            int offsetX = pos.offset(i).getX() - pos.getX();
            int offsetZ = pos.offset(i).getZ() - pos.getZ();
            if (pistonActive(pos.offset(i, -2), i, pos)) {
                return true;
            }
            if (pistonActive(pos.offset(i, -2).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
            if (pistonActive(pos.offset(i, -2).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }

            if (pistonActive(pos.offset(i, 1).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }
            if (pistonActive(pos.offset(i, 1).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
            if (pistonActive(pos.offset(i, -1).add(offsetZ, 0, offsetX), i, pos)) {
                return true;
            }
            if (pistonActive(pos.offset(i, -1).add(-offsetZ, 0, -offsetX), i, pos)) {
                return true;
            }
        }
        return false;
    }

    public static BlockPos powerPos;
}
