/**
 * PlayerESP Module
 */
package me.eve.mod.modules.impl.render;

import me.eve.api.util.*;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.BooleanSetting;
import me.eve.mod.modules.settings.impl.ColorSetting;
import net.minecraft.block.Blocks;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class DefenseESP extends Module {

	public DefenseESP() {
		super("DefenseESP", Category.Render);
		this.setDescription("Allows the player to see other players with an ESP.");
	}

	private final ColorSetting color = add(new ColorSetting("Color", new Color(255, 255, 255, 100)));
	private final BooleanSetting box = add(new BooleanSetting("Box", true));
	private final BooleanSetting outline = add(new BooleanSetting("Outline", true));
	private final BooleanSetting onlyBurrow = add(new BooleanSetting("OnlyBurrow", true));
	List<BlockPos> renderList = new ArrayList<>();
    @Override
	public void onRender3D(MatrixStack matrixStack, float partialTicks) {
		renderList.clear();
		for (Entity player : CombatUtil.getEnemies(10)) {
			BlockPos pos = EntityUtil.getEntityPos(player, true);
			BlockPos pos1 = new BlockPos(MathHelper.floor(player.getX() + 0.2), MathHelper.floor(player.getY() + 0.5), MathHelper.floor(player.getZ() + 0.2));
			BlockPos pos2 = new BlockPos(MathHelper.floor(player.getX() - 0.2), MathHelper.floor(player.getY() + 0.5), MathHelper.floor(player.getZ() + 0.2));
			BlockPos pos3 = new BlockPos(MathHelper.floor(player.getX() + 0.2), MathHelper.floor(player.getY() + 0.5), MathHelper.floor(player.getZ() - 0.2));
			BlockPos pos4 = new BlockPos(MathHelper.floor(player.getX() - 0.2), MathHelper.floor(player.getY() + 0.5), MathHelper.floor(player.getZ() - 0.2));
			if (isObsidian(pos)) {
				renderList.add(pos);
			}
			if (isObsidian(pos1)) {
				renderList.add(pos1);
			}
			if (isObsidian(pos2)) {
				renderList.add(pos2);
			}
			if (isObsidian(pos3)) {
				renderList.add(pos3);
			}
			if (isObsidian(pos4)) {
				renderList.add(pos4);
			}
			if (onlyBurrow.getValue() || !BlockUtil.isHole(pos)) continue;
			for (Direction i : Direction.values()) {
				if (i == Direction.UP || i == Direction.DOWN) continue;
				if (isObsidian(pos.offset(i))) {
					renderList.add(pos.offset(i));
				}
			}
		}
		for (BlockPos pos : renderList) {
			Render3DUtil.draw3DBox(matrixStack, new Box(pos), color.getValue(), outline.getValue(), box.getValue());
		}
	}

	private boolean isObsidian(BlockPos pos) {
		return (BlockUtil.getBlock(pos) == Blocks.OBSIDIAN || BlockUtil.getBlock(pos) == Blocks.ENDER_CHEST) && !renderList.contains(pos);
	}
}
