package me.eve.mod.modules.impl.misc;

import me.eve.api.interfaces.IMC;
import me.eve.mod.modules.Module;

public class FastPlace extends Module {
	public FastPlace() {
		super("FastPlace", Category.Misc);
		this.setDescription("Places blocks exceptionally fast");
	}

    @Override
	public void onUpdate() {
		((IMC) mc).setItemUseCooldown(0);
	}
}
