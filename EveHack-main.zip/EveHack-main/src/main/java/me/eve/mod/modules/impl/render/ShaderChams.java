package me.eve.mod.modules.impl.render;

import me.eve.Eve;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.Setting;
import me.eve.mod.modules.settings.impl.BooleanSetting;
import me.eve.mod.modules.settings.impl.ColorSetting;
import me.eve.mod.modules.settings.impl.EnumSetting;
import me.eve.mod.modules.settings.impl.SliderSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;

import java.awt.*;
import java.lang.reflect.Field;

import static me.eve.api.managers.ShaderManager.Shader;
public class ShaderChams extends Module {

    public static ShaderChams INSTANCE;

    public ShaderChams() {
        super("ShaderChams", Category.Render);
        try {
            for (Field field : ShaderChams.class.getDeclaredFields()) {
                if (!Setting.class.isAssignableFrom(field.getType()))
                    continue;
                Setting setting = (Setting) field.get(this);
                addSetting(setting);
            }
        } catch (Exception e) {
        }
        INSTANCE = this;
    }
    private enum Page {
        Shader,
        Target
    }
    private final EnumSetting page = new EnumSetting("Page", Page.Shader);

    public EnumSetting mode = new EnumSetting("Mode", Shader.Default, v -> page.getValue() == Page.Shader);
    public EnumSetting handsMode = new EnumSetting("HandsMode", Shader.Default, v -> page.getValue() == Page.Shader);
    public EnumSetting skyMode = new EnumSetting("SkyMode", Shader.Default, v -> page.getValue() == Page.Shader);
    public final SliderSetting speed = new SliderSetting("Speed", 4, 0, 20, 0.1, v -> page.getValue() == Page.Shader);
    public final BooleanSetting glow = new BooleanSetting("Glow", true, v -> page.getValue() == Page.Shader);
    public final SliderSetting quality = new SliderSetting("Quality", 3, 0, 20, v -> glow.getValue() && page.getValue() == Page.Shader);
    public final SliderSetting lineWidth = new SliderSetting("LineWidth", 2, 0, 20, v -> page.getValue() == Page.Shader);
    public final SliderSetting factor = new SliderSetting("GradientFactor", 2f, 0f, 20f, v -> page.getValue() == Page.Shader);
    public final SliderSetting gradient = new SliderSetting("Gradient", 2f, 0f, 20f, v -> page.getValue() == Page.Shader);
    public final SliderSetting alpha2 = new SliderSetting("GradientAlpha", 170, 0, 255, v -> page.getValue() == Page.Shader);
    public final SliderSetting octaves = new SliderSetting("Octaves", 10, 5, 30, v -> page.getValue() == Page.Shader);
    public final SliderSetting fillAlpha = new SliderSetting("Alpha", 170, 0, 255, v -> page.getValue() == Page.Shader);
    public final ColorSetting outlineColor = new ColorSetting("Outline", new Color(255,255,255), v -> page.getValue() == Page.Shader);
    public final ColorSetting smokeGlow = new ColorSetting("SmokeGlow", new Color(255,255,255), v -> page.getValue() == Page.Shader);
    public final ColorSetting smokeGlow1 = new ColorSetting("SmokeGlow", new Color(255,255,255), v -> page.getValue() == Page.Shader);
    public final ColorSetting fillColor2 = new ColorSetting("SmokeFill", new Color(255,255,255), v -> page.getValue() == Page.Shader);
    public final ColorSetting fillColor3 = new ColorSetting("SmokeFil2", new Color(255,255,255), v -> page.getValue() == Page.Shader);
    public final ColorSetting fill = new ColorSetting("Fill", new Color(255,255,255), v -> page.getValue() == Page.Shader);

    public final BooleanSetting sky = new BooleanSetting("Sky[!]", false, v -> page.getValue() == Page.Target);
    private final BooleanSetting hands = new BooleanSetting("Hands", true, v -> page.getValue() == Page.Target);
    public final SliderSetting maxRange = new SliderSetting("MaxRange", 64, 16, 512, v -> page.getValue() == Page.Target);
    private final BooleanSetting self = new BooleanSetting("Self", true, v -> page.getValue() == Page.Target);
    private final BooleanSetting players = new BooleanSetting("Players", true, v -> page.getValue() == Page.Target);
    private final BooleanSetting friends = new BooleanSetting("Friends", true, v -> page.getValue() == Page.Target);
    private final BooleanSetting crystals = new BooleanSetting("Crystals", true, v -> page.getValue() == Page.Target);
    private final BooleanSetting creatures = new BooleanSetting("Creatures", false, v -> page.getValue() == Page.Target);
    private final BooleanSetting monsters = new BooleanSetting("Monsters", false, v -> page.getValue() == Page.Target);
    private final BooleanSetting ambients = new BooleanSetting("Ambients", false, v -> page.getValue() == Page.Target);
    private final BooleanSetting items = new BooleanSetting("Items", true, v -> page.getValue() == Page.Target);
    private final BooleanSetting others = new BooleanSetting("Others", false, v -> page.getValue() == Page.Target);

    public boolean shouldRender(Entity entity) {
        if (entity == null)
            return false;

        if (mc.player == null)
            return false;

        if (MathHelper.sqrt((float) mc.player.squaredDistanceTo(entity.getPos())) > maxRange.getValue())
            return false;

        if (entity instanceof PlayerEntity) {
            if (entity == mc.player)
                return self.getValue();
            if (Eve.FRIEND.isFriend((PlayerEntity) entity))
                return friends.getValue();
            return players.getValue();
        }

        if (entity instanceof EndCrystalEntity)
            return crystals.getValue();
        if (entity instanceof ItemEntity)
            return items.getValue();
        return switch (entity.getType().getSpawnGroup()) {
            case CREATURE, WATER_CREATURE -> creatures.getValue();
            case MONSTER -> monsters.getValue();
            case AMBIENT, WATER_AMBIENT -> ambients.getValue();
            default -> others.getValue();
        };
    }

    @Override
    public void onRender3D(MatrixStack matrixStack, float partialTicks) {
        if (hands.getValue())
            Eve.SHADER.renderShader(()-> mc.gameRenderer.renderHand(matrixStack, mc.gameRenderer.getCamera(), mc.getTickDelta()), (Shader) handsMode.getValue());
    }

    @Override
    public void onDisable() {
        Eve.SHADER.reloadShaders();
    }
}
