package me.eve.mod.modules.impl.movement;

import me.eve.Eve;
import me.eve.api.events.eventbus.EventHandler;
import me.eve.api.events.impl.PacketEvent;
import me.eve.api.events.impl.RotateEvent;
import me.eve.api.util.Timer;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.SliderSetting;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public class TickShift extends Module {
	private final SliderSetting fastSpeed = add(new SliderSetting("FastSpeed", 1f, 0.1f, 10f, 0.1f));
	private final SliderSetting fastTime = add(new SliderSetting("FastTime", 500f, 1f, 1000f, 10f));
	private final SliderSetting slowSpeed = add(new SliderSetting("SlowSpeed", 1f, 0.1f, 10f, 0.1f));
	private final SliderSetting slowTime = add(new SliderSetting("SlowTime", 500f, 1f, 1000f, 10f));

	public static TickShift INSTANCE;

	public TickShift() {
		super("TickShift", Category.Movement);
		this.setDescription("Increases the speed of Minecraft.");
		INSTANCE = this;
	}

	private final me.eve.api.util.Timer packetListReset = new me.eve.api.util.Timer();
	private int normalLookPos;
	private int rotationMode;
	private int normalPos;
	public static float nextFloat(final float startInclusive, final float endInclusive) {
		return (startInclusive == endInclusive || endInclusive - startInclusive <= 0.0f) ? startInclusive : ((float) (startInclusive + (endInclusive - startInclusive) * Math.random()));
	}

	@EventHandler
	public final void onPacketSend(final PacketEvent.Send event) {
		if (nullCheck()) return;
		if (event.getPacket() instanceof PlayerMoveC2SPacket.PositionAndOnGround && rotationMode == 1) {
			normalPos++;
			if (normalPos > 20) {
				rotationMode = 2;
			}
		} else if (event.getPacket() instanceof PlayerMoveC2SPacket.Full && rotationMode == 2) {
			normalLookPos++;
			if (normalLookPos > 20) {
				rotationMode = 1;
			}
		}
	}

	public void onDisable() {
		Eve.TIMER.reset();
	}

	public void onEnable() {
		packetListReset.reset();
		Eve.TIMER.reset();
	}

	private final Timer timer = new Timer();
	private boolean isFast = true;

	@Override
	public void onRender3D(MatrixStack matrixStack, float partialTicks) {
		if (packetListReset.passedMs(1000L)) {
			normalPos = 0;
			normalLookPos = 0;
			rotationMode = 1;
		}
		if (isFast) {
			if (timer.passed(fastTime.getValueInt())) {
				timer.reset();
				isFast = !isFast;
				Eve.TIMER.set(slowSpeed.getValueFloat());
			} else {
				Eve.TIMER.set(fastSpeed.getValueFloat());
			}
 		} else {
			if (timer.passed(slowTime.getValueInt())) {
				timer.reset();
				isFast = !isFast;
				Eve.TIMER.set(fastSpeed.getValueFloat());
			} else {
				Eve.TIMER.set(slowSpeed.getValueFloat());
			}
		}
	}

	@EventHandler
	public final void RotateEvent(RotateEvent event) {
		event.setRotation(event.getYaw() + nextFloat(1.0f, 3.0f), event.getPitch() + nextFloat(1.0f, 3.0f));
	}
}