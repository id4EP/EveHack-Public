package me.eve.mod.commands.impl;

import me.eve.Eve;
import me.eve.api.managers.CommandManager;
import me.eve.mod.commands.Command;

import java.util.List;

public class SaveCommand extends Command {

	public SaveCommand() {
		super("save", "save", "");
	}

	@Override
	public void runCommand(String[] parameters) {
		CommandManager.sendChatMessage("\u00a7e[!] \u00a7fSaving..");
		Eve.save();
	}

	@Override
	public String[] getAutocorrect(int count, List<String> seperated) {
		return null;
	}
}
