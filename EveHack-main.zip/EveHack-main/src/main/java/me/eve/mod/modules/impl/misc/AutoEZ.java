package me.eve.mod.modules.impl.misc;

import me.eve.Eve;
import me.eve.api.events.eventbus.EventHandler;
import me.eve.api.events.impl.DeathEvent;
import me.eve.mod.modules.Module;

public class AutoEZ extends Module {
	public static AutoEZ INSTANCE;
	public AutoEZ() {
		super("AutoEZ", Category.Misc);
		INSTANCE = this;
	}

	@EventHandler
	public void onDeath(DeathEvent event) {
		if (!Eve.FRIEND.isFriend(event.getPlayer().getName().getString())) {
			mc.player.networkHandler.sendChatMessage("人生自古谁无死?遗憾的 " + event.getPlayer().getName().getString() + "被ArkHack nextgen击毙，无法与您互动");
		}
	}
}
