package me.eve.mod.modules.impl.player;

import me.eve.mod.modules.Module;

public class GhostHand extends Module {
	public static GhostHand INSTANCE;
	public boolean isActive;
	public GhostHand() {
		super("GhostHand", Category.Player);
		INSTANCE = this;
	}

	@Override
	public void onDisable() {
		isActive = false;
	}
}
