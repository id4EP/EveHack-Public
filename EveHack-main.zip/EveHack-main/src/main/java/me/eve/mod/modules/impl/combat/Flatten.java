package me.eve.mod.modules.impl.combat;

import me.eve.Eve;
import me.eve.api.util.BlockUtil;
import me.eve.api.util.EntityUtil;
import me.eve.api.util.InventoryUtil;
import me.eve.api.util.Timer;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.BooleanSetting;
import me.eve.mod.modules.settings.impl.SliderSetting;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.ExperienceOrbEntity;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.entity.projectile.thrown.ExperienceBottleEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

public class Flatten extends Module {
	public static Flatten INSTANCE;
	private final BooleanSetting rotate =
			add(new BooleanSetting("Rotate", true));
	private final BooleanSetting checkMine =
			add(new BooleanSetting("CheckMine", true));
	private final BooleanSetting inventory =
			add(new BooleanSetting("InventorySwap", true));
	private final SliderSetting delay =
			add(new SliderSetting("Delay", 500, 0, 1000));
	public Flatten() {
		super("Flatten", Category.Combat);
		INSTANCE = this;
	}

	private final Timer timer = new Timer();

	@Override
	public void onUpdate() {
		if (!mc.player.isOnGround()) {
			return;
		}
		if (!timer.passedMs(delay.getValueInt())) return;
		int oldSlot = mc.player.getInventory().selectedSlot;
		int block;
		if ((block = getBlock()) == -1) {
			return;
		}
		if (!EntityUtil.isInsideBlock()) return;

		BlockPos pos1 = new BlockPos(MathHelper.floor(mc.player.getX() + 0.6), MathHelper.floor(mc.player.getY() + 0.5), MathHelper.floor(mc.player.getZ() + 0.6)).down();
		BlockPos pos2 = new BlockPos(MathHelper.floor(mc.player.getX() - 0.6), MathHelper.floor(mc.player.getY() + 0.5), MathHelper.floor(mc.player.getZ() + 0.6)).down();
		BlockPos pos3 = new BlockPos(MathHelper.floor(mc.player.getX() + 0.6), MathHelper.floor(mc.player.getY() + 0.5), MathHelper.floor(mc.player.getZ() - 0.6)).down();
		BlockPos pos4 = new BlockPos(MathHelper.floor(mc.player.getX() - 0.6), MathHelper.floor(mc.player.getY() + 0.5), MathHelper.floor(mc.player.getZ() - 0.6)).down();

		if (!canPlace(pos1) && !canPlace(pos2) && !canPlace(pos3) && !canPlace(pos4)) {
			return;
		}
		doSwap(block);
		if (placeBlock(pos1, rotate.getValue())) {

		}
		else if (placeBlock(pos2, rotate.getValue())) {

		}
		else if (placeBlock(pos3, rotate.getValue())) {

		}
		else {
			placeBlock(pos4, rotate.getValue());
		}
		if (inventory.getValue()) {
			doSwap(block);
			EntityUtil.sync();
		} else {
			doSwap(oldSlot);
		}
	}

	private boolean placeBlock(BlockPos pos, boolean rotate) {
		if (canPlace(pos)) {
			if (checkMine.getValue() && BlockUtil.isMining(pos)) {
				return false;
			}
			Direction side;
			if ((side = BlockUtil.getPlaceSide(pos)) == null) return false;
			BlockUtil.placedPos.add(pos);
			BlockUtil.clickBlock(pos.offset(side), side.getOpposite(), rotate);
			timer.reset();
			return true;
		}
		return false;
	}

	private void doSwap(int slot) {
		if (inventory.getValue()) {
			mc.interactionManager.clickSlot(mc.player.currentScreenHandler.syncId, slot, mc.player.getInventory().selectedSlot, SlotActionType.SWAP, mc.player);
		} else {
			InventoryUtil.doSwap(slot);
		}
	}

	private boolean canPlace(BlockPos pos) {
		if (BlockUtil.getPlaceSide(pos) == null) {
			return false;
		}
		if (!BlockUtil.canReplace(pos)) {
			return false;
		}
		return !hasEntity(pos);
	}

	private boolean hasEntity(BlockPos pos) {
		for (Entity entity : mc.world.getNonSpectatingEntities(Entity.class, new Box(pos))) {
			if (entity == mc.player) continue;
			if (!entity.isAlive() || entity instanceof ItemEntity || entity instanceof ExperienceOrbEntity || entity instanceof ExperienceBottleEntity || entity instanceof ArrowEntity || entity instanceof EndCrystalEntity || entity instanceof ArmorStandEntity && Eve.HUD.obsMode.getValue())
				continue;
			return true;
		}
		return false;
	}


	private int getBlock() {
		if (inventory.getValue()) {
				return InventoryUtil.findBlockInventorySlot(Blocks.OBSIDIAN);
		} else {
				return InventoryUtil.findBlock(Blocks.OBSIDIAN);
		}
	}
}