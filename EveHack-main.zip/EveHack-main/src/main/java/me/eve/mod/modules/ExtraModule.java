package me.eve.mod.modules;

import me.eve.Eve;
import me.eve.api.util.Wrapper;
import net.minecraft.client.util.math.MatrixStack;

public class ExtraModule implements Wrapper {
    public ExtraModule() {
        Eve.EVENT_BUS.subscribe(this);
    }

    public void onRender3D(MatrixStack matrixStack, float partialTicks) {

    }
}
