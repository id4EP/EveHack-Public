package me.eve.mod.modules.impl.misc;

import me.eve.api.events.eventbus.EventHandler;
import me.eve.api.events.impl.SendMessageEvent;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.EnumSetting;

public class ChatAppend extends Module {
	public static ChatAppend INSTANCE;
	private final EnumSetting mode = add(new EnumSetting("Mode", Mode.Eve));

	public ChatAppend() {
		super("ChatSuffix", Category.Misc);
		INSTANCE = this;
	}

	private enum Mode {
		Eve,
		MoonBlade,
		Melon,
		nullPoint,
		Mio,
		Jeez,
		Scanner,
		M7thh4ck,
		Moon,
		Dream
	}

	public static String eveSuffix = "✷ᗴ\uD835\uDEF4\uD835\uDF08\uD835\uDF00";
	public static String moonbladeSuffix = "☽\uD835\uDD10\uD835\uDD2C\uD835\uDD2C\uD835\uDD2B\uD835\uDD1F\uD835\uDD29\uD835\uDD1E\uD835\uDD21\uD835\uDD22";
	public static String melonSuffix = "\uD835\uDD10\uD835\uDD22\uD835\uDD29\uD835\uDD2C\uD835\uDD2B\uD835\uDD05\uD835\uDD22\uD835\uDD31\uD835\uDD1E";
	public static final String nullPointSuffix = "\uD835\uDD2B\uD835\uDD32\uD835\uDD29\uD835\uDD29\uD835\uDD2D\uD835\uDD2C\uD835\uDD26\uD835\uDD2B\uD835\uDD31";
	public static final String mioSuffix = "⋆ ᴍɪᴏ";
	public static final String jeezSuffix = " | Jeezʜᴀck/1.4";
	public static final String scannerSuffix = " | Scanner ʜᴀᴄᴋ";
	public static final String m7thh4ckSuffix = " | \uD835\uDCC27\uD835\uDCC9\uD835\uDCBD\uD835\uDCBD4\uD835\uDCB8\uD835\uDCC0-$";
	public static final String moonSuffix = "☽\uD835\uDD10\uD835\uDD2C\uD835\uDD2C\uD835\uDD2B";
	public static final String DreamSuffix = "ᎴꮢꮛꮧꮇᎴꮛꮙ Ꮭꭷꮙꮛ ꮼ";
	@EventHandler
	public void onSendMessage(SendMessageEvent event) {
		if (nullCheck() || event.isCancel()) return;
		String message = event.message;

		if (message.startsWith("/") || message.startsWith("!") || message.endsWith(eveSuffix) || message.endsWith(moonbladeSuffix) || message.endsWith(melonSuffix)) {
			return;
		}
		String suffix = "";
		switch ((Mode) mode.getValue()) {
			case Eve -> suffix = ChatAppend.eveSuffix;
			case MoonBlade -> suffix = moonbladeSuffix;
			case Melon -> suffix = melonSuffix;
			case nullPoint -> suffix = nullPointSuffix;
			case Mio -> suffix = mioSuffix;
			case Jeez -> suffix = jeezSuffix;
			case Scanner -> suffix = scannerSuffix;
			case M7thh4ck -> suffix = m7thh4ckSuffix;
			case Moon -> suffix = moonSuffix;
			case Dream -> suffix = DreamSuffix;
		}
		message = message + " " + suffix;
		event.message = message;
	}
}