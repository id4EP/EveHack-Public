package me.eve.mod.modules.impl.render;

import me.eve.mod.modules.Module;

public class NoInvisible extends Module {
	public static NoInvisible INSTANCE;
	public NoInvisible() {
		super("NoInvisible", Category.Render);
		INSTANCE = this;
	}

}