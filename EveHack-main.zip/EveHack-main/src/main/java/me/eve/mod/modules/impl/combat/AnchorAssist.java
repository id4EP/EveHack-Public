package me.eve.mod.modules.impl.combat;

import me.eve.api.util.*;
import me.eve.mod.modules.Module;
import me.eve.mod.modules.settings.impl.BooleanSetting;
import me.eve.mod.modules.settings.Setting;
import me.eve.mod.modules.settings.impl.SliderSetting;
import net.minecraft.block.Blocks;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.lang.reflect.Field;
import java.util.ArrayList;

public class AnchorAssist extends Module {
	public static AnchorAssist INSTANCE;
	private final BooleanSetting rotate =
			new BooleanSetting("Rotate", true);
	private final BooleanSetting force =
			new BooleanSetting("Force", true);
	private final BooleanSetting usingPause =
			new BooleanSetting("UsingPause", true);
	private final BooleanSetting checkMine =
			new BooleanSetting("CheckMine", false);
	private final SliderSetting range =
			new SliderSetting("TargetRange", 5.0, 0.0, 6.0, 0.1);
	private final SliderSetting minDamage =
			new SliderSetting("MinDamage", 6.0, 0.0, 36.0, 0.1);
	private final SliderSetting delay =
			new SliderSetting("Delay", 0.0, 0.0, 0.5, 0.01);
	private final Timer timer = new Timer().reset();

	public AnchorAssist() {
		super("AnchorAssist", Category.Combat);
		INSTANCE = this;
		try {
			for (Field field : this.getClass().getDeclaredFields()) {
				if (!Setting.class.isAssignableFrom(field.getType()))
					continue;
				Setting setting = (Setting) field.get(this);
				addSetting(setting);
			}
		} catch (Exception e) {
		}
	}

	@Override
	public void onUpdate() {
		int anchor = InventoryUtil.findBlock(Blocks.RESPAWN_ANCHOR);
		int glowstone = InventoryUtil.findBlock(Blocks.GLOWSTONE);
		int old = mc.player.getInventory().selectedSlot;
		if (anchor == -1) {
			return;
		}
		if (glowstone == -1) {
			return;
		}
		if (mc.player.isSneaking()) {
			return;
		}
		if (usingPause.getValue() && mc.player.isUsingItem()) {
			return;
		}
		if (!timer.passed((long) (delay.getValueFloat() * 1000))) {
			return;
		}
		timer.reset();
		double bestDamage = AutoAnchor.INSTANCE.minDamage.getValue();
		double bestAnchorDamage = bestDamage;
		boolean anchorFound = false;
		ArrayList<AutoAnchor.PlayerAndPredict> list = new ArrayList<>();
		for (PlayerEntity player : CombatUtil.getEnemies(range.getValue())) {
			list.add(new AutoAnchor.PlayerAndPredict(player));
		}
		if (!force.getValue()) {
			for (BlockPos pos : BlockUtil.getSphere(AutoAnchor.INSTANCE.range.getValueFloat())) {
				for (AutoAnchor.PlayerAndPredict pap : list) {
					if (BlockUtil.getBlock(pos) != Blocks.RESPAWN_ANCHOR) {
						if (anchorFound) continue;
						if (!BlockUtil.canPlace(pos, AutoAnchor.INSTANCE.range.getValue())) continue;
						double damage = AutoAnchor.INSTANCE.getAnchorDamage(pos, pap.player, pap.predict);
						if (damage >= bestDamage) {
							bestDamage = damage;
						}
					} else {
						double damage = AutoAnchor.INSTANCE.getAnchorDamage(pos, pap.player, pap.predict);
						if (damage >= bestAnchorDamage) {
							anchorFound = true;
							bestAnchorDamage = damage;
							bestDamage = damage;
						}
					}
				}
			}
			if (bestDamage >= minDamage.getValue()) {
				return;
			}
		}

		bestDamage = minDamage.getValue();
		BlockPos foundPos = null;
		for (AutoAnchor.PlayerAndPredict pap : list) {
			BlockPos pos = EntityUtil.getEntityPos(pap.player, true).up(2);
			if (mc.world.getBlockState(pos).getBlock() == Blocks.RESPAWN_ANCHOR) {
				return;
			}
			if (BlockUtil.clientCanPlace(pos, false)) {
				double damage = AutoAnchor.INSTANCE.getAnchorDamage(pos, pap.player, pap.predict);
				if (damage >= bestDamage) {
					bestDamage = damage;
					foundPos = pos;
				}
			}
			for (Direction i : Direction.values()) {
				if (i == Direction.UP || i == Direction.DOWN) continue;
				if (BlockUtil.clientCanPlace(pos.offset(i), false)) {
					double damage = AutoAnchor.INSTANCE.getAnchorDamage(pos.offset(i), pap.player, pap.predict);
					if (damage >= bestDamage) {
						bestDamage = damage;
						foundPos = pos.offset(i);
					}
				}
			}
		}
		if (foundPos != null && BlockUtil.getPlaceSide(foundPos, AutoAnchor.INSTANCE.range.getValue()) == null) {
			BlockPos placePos;
			if ((placePos = getHelper(foundPos)) != null) {
				InventoryUtil.doSwap(anchor);
				BlockUtil.placeBlock(placePos, rotate.getValue());
				InventoryUtil.doSwap(old);
			}
		}
	}

	public BlockPos getHelper(BlockPos pos) {
		for (Direction i : Direction.values()) {
			if (checkMine.getValue() && BlockUtil.isMining(pos.offset(i))) continue;
			if (!BlockUtil.isStrictDirection(pos.offset(i), i.getOpposite(), true)) continue;
			if (BlockUtil.canPlace(pos.offset(i))) return pos.offset(i);
		}
		return null;
	}
}