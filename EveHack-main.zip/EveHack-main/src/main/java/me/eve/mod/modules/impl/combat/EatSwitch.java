package me.eve.mod.modules.impl.combat;

import me.eve.api.util.InventoryUtil;
import me.eve.mod.modules.Module;
import net.minecraft.item.Items;
import net.minecraft.item.PickaxeItem;

public class EatSwitch extends Module {
	public static EatSwitch INSTANCE;
	public EatSwitch() {
		super("EatSwitch", Category.Combat);
		INSTANCE = this;
	}

	boolean swapped = false;
	int lastSlot = 0;
	@Override
	public void onUpdate() {
		if (!(mc.player.getMainHandStack().getItem() instanceof PickaxeItem) && mc.player.getMainHandStack().getItem() != Items.ENCHANTED_GOLDEN_APPLE) {
			swapped = false;
			return;
		}
		int gapple = InventoryUtil.findItem(Items.ENCHANTED_GOLDEN_APPLE);
		if (gapple == -1) {
			if (swapped) {
				InventoryUtil.doSwap(lastSlot);
				swapped = false;
			}
			return;
		}
		if (mc.options.useKey.isPressed()) {
			if (mc.player.getMainHandStack().getItem() instanceof PickaxeItem && mc.player.getOffHandStack().getItem() != Items.ENCHANTED_GOLDEN_APPLE) {
				lastSlot = mc.player.getInventory().selectedSlot;
				InventoryUtil.doSwap(gapple);
				swapped = true;
			}
		} else if (swapped) {
			InventoryUtil.doSwap(lastSlot);
			swapped = false;
		}
	}
}