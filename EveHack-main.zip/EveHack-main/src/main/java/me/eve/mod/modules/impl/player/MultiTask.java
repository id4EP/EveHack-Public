package me.eve.mod.modules.impl.player;

import me.eve.mod.modules.Module;

public class MultiTask extends Module {
    public static MultiTask INSTANCE;
    public MultiTask() {
        super("MultiTask", Category.Player);
        INSTANCE = this;
    }
}
